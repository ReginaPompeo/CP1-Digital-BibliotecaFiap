package com.fiap.cp4.LibraryFiap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryFiapApplicationTests {

	@Test
	void contextLoads() {
	}

}
