package com.fiap.cp4.LibraryFiap;

import com.fiap.cp4.LibraryFiap.controller.LivroController;
import com.fiap.cp4.LibraryFiap.controller.dto.LivroDTO;
import com.fiap.cp4.LibraryFiap.entity.Livro;
import com.fiap.cp4.LibraryFiap.service.LivroService;
import com.fiap.cp4.LibraryFiap.service.mapper.LivroMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Date;

import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class LivroControllerTest {

    @Mock
    private LivroService livroService;

    @InjectMocks
    private LivroController livroController;

    private LivroDTO livroDTO;

    @BeforeEach
    void setUp() {
        livroDTO = new LivroDTO();
        livroDTO.setTitulo("Livro Teste");
        livroDTO.setAutor("Autor Teste");
        livroDTO.setPublicacao(new Date(System.currentTimeMillis()));
        livroDTO.setCategoria("Categoria Teste");
    }

    @Test
    void criarLivro() {
        Livro livro = LivroMapper.toEntity(livroDTO);

        when(livroService.criarLivro(any(Livro.class))).thenReturn(livro);

        ResponseEntity<LivroDTO> responseEntity = livroController.criarLivro(livroDTO);

        verify(livroService, times(1)).criarLivro(any(Livro.class));
        assert responseEntity.getStatusCode() == HttpStatus.OK;
        assert responseEntity.getBody() != null;
        assert responseEntity.getBody().getTitulo().equals(livroDTO.getTitulo());
    }

    @Test
    void criarLivroException() {
        when(livroService.criarLivro(any(Livro.class))).thenThrow(new RuntimeException());

        ResponseEntity<LivroDTO> responseEntity = livroController.criarLivro(livroDTO);

        verify(livroService, times(1)).criarLivro(any(Livro.class));
        assert responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR;
        assert responseEntity.getBody() == null;
    }
}
