package com.fiap.cp4.LibraryFiap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryFiapApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryFiapApplication.class, args);
	}

}
