package com.fiap.cp4.LibraryFiap.service.mapper;

import com.fiap.cp4.LibraryFiap.controller.dto.LivroDTO;
import com.fiap.cp4.LibraryFiap.entity.Livro;
public class LivroMapper {
    public static Livro toEntity(LivroDTO livroDTO) {
        Livro livro = new Livro();
        livro.setTitulo(livroDTO.getTitulo());
        livro.setAutor(livroDTO.getAutor());
        livro.setPublicacao(livroDTO.getPublicacao());
        livro.setCategoria(livroDTO.getCategoria());
        return livro;
    }

    public static LivroDTO toDTO(Livro entity) {
        LivroDTO dto = new LivroDTO();
        dto.setTitulo(entity.getTitulo());
        dto.setAutor(entity.getAutor());
        dto.setPublicacao(entity.getPublicacao());
        dto.setCategoria(entity.getCategoria());
        return dto;
    }

}
