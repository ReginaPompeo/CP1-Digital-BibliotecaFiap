package com.fiap.cp4.LibraryFiap.strategy;

import com.fiap.cp4.LibraryFiap.entity.Livro;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Primary
@Component
public class ClassificarPorTitulo implements ClassificadorStrategy {
    @Override
    public List<Livro> classify(List<Livro> livros) {
        return livros.stream()
                .sorted(Comparator.comparing(Livro::getTitulo))
                .collect(Collectors.toList());
    }
}
