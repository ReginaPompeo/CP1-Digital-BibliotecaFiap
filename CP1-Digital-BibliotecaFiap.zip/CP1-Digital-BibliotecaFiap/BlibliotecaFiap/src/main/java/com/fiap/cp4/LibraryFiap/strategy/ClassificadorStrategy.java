package com.fiap.cp4.LibraryFiap.strategy;

import com.fiap.cp4.LibraryFiap.entity.Livro;

import java.util.List;

public interface ClassificadorStrategy {
    List<Livro> classify(List<Livro> livros);
}
